# Financial Statement & Ratio Analysis — Aravind Consumer Products Ltd.

## Project Overview
This project presents a comprehensive **Financial Statement & Ratio Analysis** of **Aravind Consumer Products Ltd.**, a fictional Indian consumer-products company created for portfolio demonstration.

The analysis converts financial statements into management insights covering profitability, liquidity, leverage, efficiency, cash flow, working capital, DuPont analysis, segment economics and peer benchmarking.

> **Core Question:** What does the financial data reveal about the company's financial health, operating efficiency and strategic priorities?

## Objectives
- Analyze the income statement
- Analyze the balance sheet
- Evaluate profitability
- Evaluate liquidity
- Evaluate leverage and solvency
- Analyze asset and working-capital efficiency
- Analyze operating and free cash flow
- Perform DuPont analysis
- Compare business segments
- Benchmark against illustrative peers
- Build an investor-oriented scorecard
- Identify financial risks
- Develop strategic financial recommendations
- Build a management KPI framework

## Analytical Framework
**Financial Statements → Ratio Analysis → Trend Analysis → Peer Benchmarking → Risk Assessment → Strategic Recommendations**

## Major Findings
- Revenue grows across the modeled period.
- FY2025 shows profitability pressure.
- Liquidity remains comfortable.
- Leverage rises through FY2025 before improving in FY2026E.
- FY2025 free cash flow is negative because of elevated capex.
- FY2026E models stronger cash generation and gradual deleveraging.

## Key Ratios
### Profitability
Gross Margin, EBIT Margin, Net Margin, ROA and ROE.

### Liquidity
Current Ratio, Quick Ratio and Working Capital.

### Leverage
Debt-to-Equity, Debt-to-EBITDA and Interest Coverage.

### Efficiency
Asset Turnover, Inventory Turnover and Receivables Turnover.

## DuPont Analysis
**ROE = Net Profit Margin × Asset Turnover × Equity Multiplier**

This identifies whether shareholder returns are driven by profitability, asset efficiency or financial leverage.

## Segment Analysis
The fictional business contains:
- Personal Care
- Home Care
- Food & Beverage
- Small Appliances

Each segment is evaluated using revenue, margin, growth and strategic action.

## Peer Benchmarking
The company is compared with three illustrative peers using revenue growth, EBIT margin, net margin, ROE, debt-to-equity and current ratio.

**Peer data is synthetic and intended only for analytical demonstration.**

## Strategic Recommendations
1. Protect gross margin through pricing and product mix.
2. Improve inventory turnover.
3. Tighten receivables management.
4. Maintain disciplined capital expenditure.
5. Gradually reduce leverage using free cash flow.
6. Monitor interest coverage.
7. Improve segment-level profitability.
8. Prioritize investments with strong return potential.
9. Track free cash flow conversion.
10. Link financial ratios to operational KPIs.

## Repository Structure
```text
financial-statement-ratio-analysis/
├── README.md
├── PDF_Files/
├── Data/
└── Charts/
```

## Tools & Skills
**Tools:** Microsoft Excel, Financial Modeling, Data Analysis, Data Visualization

**Skills:** Financial Statement Analysis, Ratio Analysis, Financial Modeling, Profitability Analysis, Liquidity Analysis, Leverage Analysis, Working Capital Management, Cash Flow Analysis, DuPont Analysis, Peer Benchmarking, Risk Analysis, Strategic Financial Management, KPI Development.

## Important Disclosure
**Aravind Consumer Products Ltd. is a fictional company created specifically for this portfolio project.**

All financial statements, historical figures, ratios, peer data, operating metrics and FY2026E forecasts are **synthetic/illustrative**.

They do not represent actual company financial performance, actual financial statements, actual market data, actual peer-company data, investment recommendations or financial forecasts.

This project is intended for **portfolio, educational and demonstration purposes**.

## Suggested LinkedIn Description
Developed a comprehensive financial statement and ratio analysis for a fictional Indian consumer-products company using a synthetic multi-year financial model. Analyzed income statement, balance sheet, cash flow, profitability, liquidity, leverage, efficiency, working capital, DuPont ROE drivers, segment performance and peer benchmarking. Built an Excel-based financial model, investor scorecard, risk assessment and strategic financial recommendations.

## Author
**Snehil Raj**

B.Tech — Electrical & Electronics Engineering

⭐ Portfolio Project — Financial Analysis & Strategic Financial Management
